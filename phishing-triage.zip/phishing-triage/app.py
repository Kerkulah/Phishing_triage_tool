
""" Kerkulah Collins 02/16/2025

 Flask REST API for phishing triage.

Endpoints:
  POST /api/triage     — analyze an uploaded .eml file
  GET  /api/health     — health check
  GET  /               — serve the web UI

"""
import os
import json
import logging
from pathlib import Path
from flask import Flask, request, jsonify, render_template_string, send_from_directory
from flask_cors import CORS

from triage.parser import parse_eml
from triage.auth import analyze_auth
from triage.ioc import analyze_urls
from triage.scorer import score_email
from triage.enrichment import enrich
from triage.reporter import (
    generate_json_report, generate_markdown_ticket, build_case_id
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder="static")
CORS(app)

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB

MINIMAL_UI = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Phishing Triage Tool</title>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: #0d1117;
    color: #ffffff;
    font-family: 'Courier New', monospace;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .wrapper {
    width: 100%;
    max-width: 640px;
    padding: 2rem;
  }
  h1 { font-size: 1.6rem; margin-bottom: .5rem; color: #ffffff; }
  .sub { opacity: .6; font-size: .85rem; margin-bottom: 2rem; color: #ffffff; }
  .card { border: 1px solid #2a2a2a; border-radius: 8px; padding: 1.5rem; }
  label { display: block; margin-bottom: .5rem; font-size: .85rem; opacity: .8; color: #ffffff; }
  input[type=file] { color: #ffffff; margin-bottom: 1rem; }
  label.check { display: flex; align-items: center; gap: .5rem; margin-bottom: .5rem; font-size: .8rem; opacity: .7; color: #ffffff; }
  input[type=checkbox] { accent-color: #ffffff; }
  button {
    background: #cc0000;
    border: 1px solid #ff2222;
    color: #ffffff;
    font-family: monospace;
    padding: .6rem 2rem;
    cursor: pointer;
    font-size: .9rem;
    border-radius: 4px;
    margin-top: 1rem;
    letter-spacing: 1px;
  }
  button:hover { background: #aa0000; }
  button:disabled { opacity: .5; cursor: not-allowed; }
  #result {
    margin-top: 2rem;
    white-space: pre-wrap;
    font-size: .75rem;
    background: #111111;
    border: 1px solid #2a2a2a;
    border-radius: 8px;
    padding: 1rem;
    max-height: 60vh;
    overflow-y: auto;
    color: #ffffff;
  }
  .verdict { font-size: 1.4rem; font-weight: bold; letter-spacing: 3px; margin-bottom: .5rem; }
  .PHISHING { color: #ff4444; }
  .SUSPICIOUS { color: #ffaa00; }
  .CLEAN { color: #44ff44; }
  .spinner { display: none; margin-left: 1rem; opacity: .7; color: #ffffff; }
  details summary { cursor: pointer; margin-bottom: .5rem; color: #aaaaaa; }
</style>
</head>
<body>
<div class="wrapper">
  <h1>Phishing Triage Tool</h1>
  <p class="sub"> [] drop in a .eml | get an analyst ready verdict in under a second </p>

  <div class="card">
    <label>Upload .eml file</label>
    <input type="file" id="file-input" accept=".eml,.txt">

    <label class="check">
      <input type="checkbox" id="enrich-cb">
      Enable threat intel enrichment (requires API keys in config)
    </label>

    <button id="analyze-btn" onclick="analyze()">ANALYZE</button>
    <span class="spinner" id="spinner">analyzing...</span>
  </div>

  <div id="result" style="display:none"></div>
</div>

<script>
async function analyze() {
  const file = document.getElementById('file-input').files[0];
  if (!file) { alert('Select an .eml file first.'); return; }
  const enrich = document.getElementById('enrich-cb').checked;

  document.getElementById('spinner').style.display = 'inline';
  document.getElementById('analyze-btn').disabled = true;

  const fd = new FormData();
  fd.append('file', file);
  fd.append('enrich', enrich ? '1' : '0');

  try {
    const r = await fetch('/api/triage', { method: 'POST', body: fd });
    const data = await r.json();
    const el = document.getElementById('result');
    el.style.display = 'block';

    if (data.error) {
      el.textContent = 'ERROR: ' + data.error;
      return;
    }

    const v = data.verdict;
    el.innerHTML = `<div class="verdict ${v}">${v} — ${data.risk_score}/100</div>` +
      '<div style="opacity:.7;font-size:.8rem;margin-bottom:1rem">' + data.triage_summary + '</div>' +
      '<details><summary>Full JSON Report</summary>' +
      '<pre>' + JSON.stringify(data, null, 2) + '</pre></details>';
  } catch(e) {
    document.getElementById('result').textContent = 'Request failed: ' + e;
  } finally {
    document.getElementById('spinner').style.display = 'none';
    document.getElementById('analyze-btn').disabled = false;
  }
}
</script>
</body>
</html>"""


@app.route("/")
def index():
    static_ui = Path("static/index.html")
    if static_ui.exists():
        return send_from_directory("static", "index.html")
    return MINIMAL_UI


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "service": "phishing-triage"})


@app.route("/api/triage", methods=["POST"])
def triage():
    if "file" not in request.files:
        return jsonify({"error": "No file provided. POST a .eml as multipart 'file' field."}), 400

    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename."}), 400

    raw_bytes = f.read(MAX_FILE_SIZE + 1)
    if len(raw_bytes) > MAX_FILE_SIZE:
        return jsonify({"error": f"File too large (max {MAX_FILE_SIZE // 1024 // 1024} MB)."}), 413

    do_enrich = request.form.get("enrich", "0") == "1"

    try:
        parsed = parse_eml(raw_bytes)
    except Exception as e:
        logger.exception("Failed to parse EML")
        return jsonify({"error": f"Failed to parse email: {e}"}), 422

    auth = analyze_auth(parsed)
    url_iocs = analyze_urls(parsed.urls)

    enrichment = None
    if do_enrich:
        try:
            enrichment = enrich(
                urls=parsed.urls,
                sender_ip=auth.sender_ip,
                vt_key=os.getenv("VIRUSTOTAL_API_KEY", ""),
                abuseipdb_key=os.getenv("ABUSEIPDB_API_KEY", ""),
                shodan_key=os.getenv("SHODAN_API_KEY", ""),
            )
        except Exception as e:
            logger.warning(f"Enrichment failed (non-fatal): {e}")

    scoring = score_email(parsed, auth, url_iocs, enrichment)
    case_id = build_case_id()

    report = generate_json_report(
        case_id=case_id,
        filename=f.filename,
        parsed=parsed,
        auth=auth,
        url_iocs=url_iocs,
        scoring=scoring,
        enrichment=enrichment,
    )

    logger.info(f"[{case_id}] {f.filename} → {scoring.verdict} ({scoring.score}/100)")
    return jsonify(report)


@app.route("/api/triage/markdown", methods=["POST"])
def triage_markdown():
    """Same as /api/triage but returns a Markdown ticket instead of JSON."""
    if "file" not in request.files:
        return jsonify({"error": "No file provided."}), 400

    f = request.files["file"]
    raw_bytes = f.read(MAX_FILE_SIZE + 1)
    if len(raw_bytes) > MAX_FILE_SIZE:
        return jsonify({"error": "File too large."}), 413

    parsed = parse_eml(raw_bytes)
    auth = analyze_auth(parsed)
    url_iocs = analyze_urls(parsed.urls)
    scoring = score_email(parsed, auth, url_iocs)
    case_id = build_case_id()

    report = generate_json_report(
        case_id=case_id, filename=f.filename,
        parsed=parsed, auth=auth, url_iocs=url_iocs, scoring=scoring,
    )
    md = generate_markdown_ticket(report)

    return app.response_class(md, mimetype="text/markdown",
                              headers={"Content-Disposition": f'attachment; filename="{case_id}.md"'})


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8080))
    debug = os.getenv("FLASK_DEBUG", "0") == "1"
    logger.info(f"Starting phishing-triage on port {port} (debug={debug})")
    app.run(host="0.0.0.0", port=port, debug=debug)



