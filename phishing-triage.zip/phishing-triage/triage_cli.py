#!/usr/bin/env python3
""" Kerkulah Collins 02/19/2025
 — Command-line phishing triage tool.

Usage:
  python triage_cli.py email.eml
  python triage_cli.py email.eml --enrich --output-dir ./cases
  python triage_cli.py email.eml --json
  python triage_cli.py *.eml --batch

Options:
  --enrich          Query VirusTotal, URLhaus, AbuseIPDB, Shodan
  --json            Print raw JSON to stdout (for piping)
  --output-dir DIR  Save JSON case + Markdown ticket here (default: ./cases)
  --no-save         Don't save output files (just print verdict)
  --batch           Process multiple files; summary table at the end
  --quiet           Suppress banner and progress; print verdict only
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

# ── ANSI colors ───────────────────────────────────────────────────────────────
GREEN = "\033[92m"
RED = "\033[91m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"

VERDICT_COLOR = {"PHISHING": RED, "SUSPICIOUS": YELLOW, "CLEAN": GREEN}
SEVERITY_COLOR = {"HIGH": RED, "MEDIUM": YELLOW, "LOW": CYAN, "INFO": DIM}


def banner():
    print(f"""
{GREEN}{BOLD} --------------------------------------------------------
| [] drop in a .eml | get an analyst ready verdict in under a second |
|____________________________________________________________________|{RESET}

""")


def verdict_bar(score: int, width: int = 40) -> str:
    filled = int(score / 100 * width)
    color = RED if score >= 70 else (YELLOW if score >= 35 else GREEN)
    bar = "█" * filled + "░" * (width - filled)
    return f"{color}{bar}{RESET} {score}/100"


def process_file(eml_path: Path, args) -> dict:
    from triage.parser import parse_eml
    from triage.auth import analyze_auth
    from triage.ioc import analyze_urls
    from triage.scorer import score_email
    from triage.enrichment import enrich
    from triage.reporter import (
        generate_json_report, generate_markdown_ticket, build_case_id
    )

    quiet = args.quiet

    if not quiet:
        print(f"\n{DIM}[*] Parsing {eml_path.name}...{RESET}")

    t0 = time.perf_counter()

    with open(eml_path, "rb") as f:
        raw = f.read()

    parsed = parse_eml(raw)

    if not quiet:
        print(f"{DIM}[*] Analyzing authentication headers...{RESET}")
    auth = analyze_auth(parsed)

    if not quiet:
        print(f"{DIM}[*] Extracting and analyzing URLs ({len(parsed.urls)} found)...{RESET}")
    url_iocs = analyze_urls(parsed.urls)

    enrichment = None
    if args.enrich:
        if not quiet:
            print(f"{DIM}[*] Querying threat intel feeds...{RESET}")
        enrichment = enrich(
            urls=parsed.urls,
            sender_ip=auth.sender_ip,
            vt_key=os.getenv("VIRUSTOTAL_API_KEY", ""),
            abuseipdb_key=os.getenv("ABUSEIPDB_API_KEY", ""),
            shodan_key=os.getenv("SHODAN_API_KEY", ""),
        )

    if not quiet:
        print(f"{DIM}[*] Computing risk score...{RESET}")
    scoring = score_email(parsed, auth, url_iocs, enrichment)
    case_id = build_case_id()
    elapsed = time.perf_counter() - t0

    report = generate_json_report(
        case_id=case_id,
        filename=eml_path.name,
        parsed=parsed,
        auth=auth,
        url_iocs=url_iocs,
        scoring=scoring,
        enrichment=enrichment,
    )

    if args.json:
        print(json.dumps(report, indent=2))
        return report

    if not quiet:
        vc = VERDICT_COLOR.get(scoring.verdict, "")
        print(f"""
{BOLD}{'─'*54}{RESET}
  Case ID  : {CYAN}{case_id}{RESET}
  File     : {eml_path.name}
  From     : {parsed.from_header}
  Subject  : {parsed.subject}
  Date     : {parsed.date}
{'─'*54}
  {BOLD}VERDICT  : {vc}{scoring.verdict}{RESET}
  Score    : {verdict_bar(scoring.score)}
  Time     : {elapsed*1000:.0f}ms
{'─'*54}""")

        print(f"\n  {BOLD}Authentication{RESET}")
        auth_data = [
            ("SPF", auth.spf, auth.spf_detail),
            ("DKIM", auth.dkim, auth.dkim_detail),
            ("DMARC", auth.dmarc, auth.dmarc_detail),
        ]
        for label, result, detail in auth_data:
            color = GREEN if result == "PASS" else (RED if result == "FAIL" else YELLOW)
            print(f"  {label:6} {color}{result:8}{RESET} {DIM}{detail}{RESET}")

        if auth.sender_ip:
            print(f"  {'IP':6} {CYAN}{auth.sender_ip}{RESET}  {DIM}{auth.sender_hostname or ''}{RESET}")

        if scoring.signals:
            print(f"\n  {BOLD}Scoring Signals{RESET}")
            for sig in scoring.signals:
                sc = SEVERITY_COLOR.get(sig.severity, "")
                print(f"  {sc}[{sig.severity:6}]{RESET} +{sig.weight:2}  {sig.title}")
                print(f"           {DIM}{sig.detail}{RESET}")
                if sig.mitre_technique:
                    print(f"           {DIM}MITRE: {sig.mitre_technique}{RESET}")

        if url_iocs:
            print(f"\n  {BOLD}URLs ({len(url_iocs)}){RESET}")
            for u in url_iocs[:6]:
                flags = []
                if u.is_typosquat: flags.append(f"typosquat:{u.typosquat_target}")
                if u.is_tracking_pixel: flags.append("tracking")
                if u.is_ip: flags.append("ip-host")
                if u.is_http: flags.append("http")
                flag_str = f"  {RED}{', '.join(flags)}{RESET}" if flags else ""
                print(f"  {YELLOW}{u.defanged[:72]}{RESET}{flag_str}")
            if len(url_iocs) > 6:
                print(f"  {DIM}... and {len(url_iocs)-6} more{RESET}")

        if parsed.attachments:
            print(f"\n  {BOLD}Attachments{RESET}")
            for a in parsed.attachments:
                color = RED if a.is_suspicious else DIM
                print(f"  {color}{'⚠' if a.is_suspicious else ''} {a.filename} ({a.size} bytes){RESET}")

        if enrichment:
            print(f"\n  {BOLD}Threat Intel{RESET}")
            for vt in enrichment.virustotal:
                if not vt.error:
                    c = RED if vt.malicious > 0 else GREEN
                    print(f"  VT        {c}{vt.malicious}/{vt.total} engines{RESET}  {DIM}{vt.url[:60]}{RESET}")
            for uh in enrichment.urlhaus:
                if not uh.error:
                    c = RED if uh.status in ("online", "listed") else GREEN
                    print(f"  URLhaus   {c}{uh.status}{RESET}  {DIM}{uh.url[:60]}{RESET}")
            if enrichment.abuseipdb and not enrichment.abuseipdb.error:
                ab = enrichment.abuseipdb
                c = RED if ab.abuse_score >= 50 else (YELLOW if ab.abuse_score > 0 else GREEN)
                print(f"  AbuseIPDB {c}score {ab.abuse_score}/100{RESET}  {DIM}{ab.isp} ({ab.country}){RESET}")

        print(f"\n  {DIM}{scoring.triage_summary}{RESET}\n")

    # Save files
    if not args.no_save:
        out_dir = Path(args.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        json_path = out_dir / f"{case_id}.json"
        md_path = out_dir / f"{case_id}.md"

        from triage.reporter import generate_markdown_ticket
        json_path.write_text(json.dumps(report, indent=2))
        md_path.write_text(generate_markdown_ticket(report))

        if not quiet:
            print(f"  {DIM} Saved: {json_path}{RESET}")
            print(f"  {DIM} Saved: {md_path}{RESET}\n")

    return report


def main():
    parser = argparse.ArgumentParser(
        description="Phishing Triage Tool — analyst-ready verdict in under a second.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("files", nargs="+", help=".eml file(s) to analyze")
    parser.add_argument("--enrich", action="store_true",
                        help="Query VirusTotal, URLhaus, AbuseIPDB, Shodan")
    parser.add_argument("--json", action="store_true",
                        help="Output raw JSON to stdout")
    parser.add_argument("--output-dir", default="cases",
                        help="Directory to save case files (default: ./cases)")
    parser.add_argument("--no-save", action="store_true",
                        help="Don't save output files")
    parser.add_argument("--quiet", action="store_true",
                        help="Print verdict only")
    args = parser.parse_args()

    if not args.quiet and not args.json:
        banner()

    results = []
    errors = []

    for file_arg in args.files:
        path = Path(file_arg)
        if not path.exists():
            print(f"{RED}[!] File not found: {file_arg}{RESET}", file=sys.stderr)
            errors.append((file_arg, "File not found"))
            continue
        try:
            r = process_file(path, args)
            results.append((path.name, r["verdict"], r["risk_score"]))
        except Exception as e:
            print(f"{RED}[!] Failed to process {file_arg}: {e}{RESET}", file=sys.stderr)
            errors.append((file_arg, str(e)))

    # Batch summary
    if len(results) > 1 and not args.quiet and not args.json:
        print(f"\n{BOLD}{'─'*54}")
        print(f"  BATCH SUMMARY ({len(results)} files)")
        print(f"{'─'*54}{RESET}")
        for name, verdict, score in results:
            vc = VERDICT_COLOR.get(verdict, "")
            print(f"  {name[:36]:38} {vc}{verdict:12}{RESET} {score}/100")
        if errors:
            for name, err in errors:
                print(f"  {name[:36]:38} {RED}ERROR{RESET}     {err}")
        print()

    # Exit code: 1 if any phishing found, 2 if errors, 0 if clean
    if errors:
        sys.exit(2)
    if any(v == "PHISHING" for _, v, _ in results):
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
