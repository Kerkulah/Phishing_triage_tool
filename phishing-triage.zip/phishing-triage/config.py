"""
Configuration and API key management.

Set keys here or via environment variables. Environment variables take priority. Never commit keys for production.
"""
import os

# Threat Intel API Keys
# Get your free API key at: https://www.virustotal.com/gui/home/upload
VIRUSTOTAL_API_KEY = os.getenv("VIRUSTOTAL_API_KEY", "")

# Get your free API key at: https://www.abuseipdb.com
# ABUSEIPDB_API_KEY = os.getenv("ABUSEIPDB_API_KEY", "")

# Get your free API key at: https://account.shodan.io/login
# SHODAN_API_KEY = os.getenv("SHODAN_API_KEY", "")



# ── App Settings
PORT = int(os.getenv("PORT", 8080))
DEBUG = os.getenv("FLASK_DEBUG", "0") == "1"
MAX_FILE_SIZE_MB = int(os.getenv("MAX_FILE_SIZE_MB", 10))

# Max URLs to enrich per email (avoid burning API quotas)
MAX_URLS_TO_ENRICH = int(os.getenv("MAX_URLS_TO_ENRICH", 5))

# ── Output 
DEFAULT_OUTPUT_DIR = os.getenv("OUTPUT_DIR", "cases")
