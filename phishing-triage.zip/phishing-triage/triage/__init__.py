"""
phishing-triage — analyst-ready verdict in under a second.
"""
from .parser import parse_eml
from .auth import analyze_auth
from .ioc import analyze_urls
from .scorer import score_email
from .reporter import generate_json_report, generate_markdown_ticket, build_case_id

__all__ = [
    "parse_eml",
    "analyze_auth",
    "analyze_urls",
    "score_email",
    "generate_json_report",
    "generate_markdown_ticket",
    "build_case_id",
]
