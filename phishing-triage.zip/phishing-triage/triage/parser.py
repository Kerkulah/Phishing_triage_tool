"""  Kerkulah Collins 02/22/2025
EML parsing: headers, body, URLs, attachments
"""
import email
import email.policy
import hashlib
import re
import html
from email import message_from_bytes, message_from_string
from email.header import decode_header
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Attachment:
    filename: str
    content_type: str
    size: int
    md5: str
    sha256: str
    is_suspicious: bool


@dataclass
class ParsedEmail:
    raw: str
    from_header: str
    from_name: str
    from_address: str
    to: str
    subject: str
    date: str
    message_id: str
    return_path: str
    reply_to: str
    x_mailer: str
    received: list[str]
    dkim_signature: str
    body_text: str
    body_html: str
    urls: list[str]
    attachments: list[Attachment]
    headers_raw: dict


def decode_header_value(value: str) -> str:
    """Decode encoded email header values (RFC 2047)."""
    if not value:
        return ""
    parts = decode_header(value)
    decoded = []
    for part, charset in parts:
        if isinstance(part, bytes):
            try:
                decoded.append(part.decode(charset or "utf-8", errors="replace"))
            except (LookupError, UnicodeDecodeError):
                decoded.append(part.decode("latin-1", errors="replace"))
        else:
            decoded.append(part)
    return " ".join(decoded)


def extract_address(header_val: str) -> tuple[str, str]:
    """Extract display name and email address from a From header."""
    if not header_val:
        return "", ""
    match = re.match(r'^"?([^"<]*)"?\s*<?([^>]+@[^>]+)>?$', header_val.strip())
    if match:
        return match.group(1).strip(), match.group(2).strip().lower()
    if "@" in header_val:
        return "", header_val.strip().strip("<>").lower()
    return header_val.strip(), ""


def extract_urls(text: str) -> list[str]:
    """Extract all URLs from raw text/html."""
    pattern = re.compile(
        r'https?://[^\s"\'<>\)\]\,;]+',
        re.IGNORECASE
    )
    urls = pattern.findall(text)
    # Also grab href= links
    href_pattern = re.compile(r'href=["\']?(https?://[^"\'>\s]+)', re.IGNORECASE)
    hrefs = href_pattern.findall(text)
    all_urls = list(dict.fromkeys(urls + hrefs))  # deduplicate, preserve order
    return all_urls


def hash_bytes(data: bytes) -> tuple[str, str]:
    return (
        hashlib.md5(data).hexdigest(),
        hashlib.sha256(data).hexdigest()
    )


SUSPICIOUS_EXTENSIONS = {
    ".exe", ".dll", ".bat", ".cmd", ".ps1", ".vbs", ".js", ".jar",
    ".scr", ".pif", ".com", ".hta", ".wsf", ".msi", ".reg",
    ".docm", ".xlsm", ".pptm", ".zip", ".rar", ".7z", ".iso", ".img"
}


def parse_eml(raw: str | bytes) -> ParsedEmail:
    """Parse a raw .eml string or bytes into a ParsedEmail dataclass."""
    if isinstance(raw, bytes):
        msg = message_from_bytes(raw, policy=email.policy.compat32)
        raw_str = raw.decode("utf-8", errors="replace")
    else:
        msg = message_from_string(raw, policy=email.policy.compat32)
        raw_str = raw

    def hdr(key: str) -> str:
        return decode_header_value(msg.get(key, ""))

    from_raw = hdr("From")
    from_name, from_address = extract_address(from_raw)

    received = [str(r) for r in msg.get_all("Received") or []]

    # Collect raw headers
    headers_raw = {}
    for k in msg.keys():
        headers_raw[k.lower()] = hdr(k)

    body_text = ""
    body_html = ""
    attachments = []

    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            cd = str(part.get("Content-Disposition") or "")
            filename = part.get_filename()

            if filename:
                filename = decode_header_value(filename)
                payload = part.get_payload(decode=True) or b""
                md5, sha256 = hash_bytes(payload)
                ext = "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
                attachments.append(Attachment(
                    filename=filename,
                    content_type=ct,
                    size=len(payload),
                    md5=md5,
                    sha256=sha256,
                    is_suspicious=ext in SUSPICIOUS_EXTENSIONS,
                ))
            elif ct == "text/plain" and "attachment" not in cd:
                payload = part.get_payload(decode=True) or b""
                body_text += payload.decode("utf-8", errors="replace")
            elif ct == "text/html" and "attachment" not in cd:
                payload = part.get_payload(decode=True) or b""
                body_html += payload.decode("utf-8", errors="replace")
    else:
        ct = msg.get_content_type()
        payload = msg.get_payload(decode=True) or b""
        decoded = payload.decode("utf-8", errors="replace")
        if ct == "text/html":
            body_html = decoded
        else:
            body_text = decoded

    # Extract URLs from both body and raw source
    urls = extract_urls(raw_str + body_html + body_text)

    return ParsedEmail(
        raw=raw_str,
        from_header=from_raw,
        from_name=from_name,
        from_address=from_address,
        to=hdr("To"),
        subject=hdr("Subject"),
        date=hdr("Date"),
        message_id=hdr("Message-ID"),
        return_path=hdr("Return-Path"),
        reply_to=hdr("Reply-To"),
        x_mailer=hdr("X-Mailer"),
        received=received,
        dkim_signature=hdr("DKIM-Signature"),
        body_text=body_text,
        body_html=body_html,
        urls=urls,
        attachments=attachments,
        headers_raw=headers_raw,
    )
