"""  Kerkulah Collins 02/16/2025

 SPF, DKIM, DMARC alignment analysis from email headers.
"""
import re
from dataclasses import dataclass
from typing import Optional


@dataclass
class AuthResult:
    # Domains
    from_domain: str
    envelope_from_domain: str
    dkim_domain: str
    reply_to_domain: str

    # Auth results
    spf: str          # PASS / FAIL / SOFTFAIL / NEUTRAL / NONE
    spf_detail: str
    dkim: str         # PASS / FAIL / NONE
    dkim_detail: str
    dmarc: str        # PASS / FAIL / NONE
    dmarc_detail: str

    # Sender IP
    sender_ip: Optional[str]
    sender_hostname: Optional[str]


def extract_domain(email_addr: str) -> str:

    """Pull the domain from an email address or Return Path header."""

    addr = email_addr.strip().strip("<>")
    match = re.search(r"@([\w.\-]+)", addr)
    return match.group(1).lower() if match else ""


def extract_dkim_domain(dkim_sig: str) -> str:
    match = re.search(r"\bd=([\w.\-]+)", dkim_sig)
    return match.group(1).lower() if match else ""


def extract_sender_ip(received_headers: list[str]) -> tuple[Optional[str], Optional[str]]:

    """
    Extract the originating sender IP from the first Received header
    that contains an external IP address.
    """

    for rcv in received_headers:
        # Match 'from x.x.x.x' or '(x.x.x.x)' patterns
        ip_match = re.search(
            r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", rcv
        )
        hostname_match = re.search(r"from\s+([\w.\-]+)\s", rcv)
        if ip_match:
            return ip_match.group(1), (hostname_match.group(1) if hostname_match else None)
    return None, None


def check_dkim_structure(dkim_sig: str) -> tuple[str, str]:

    """
    Structurally validate a DKIM Signature header.
    Full crypto verification requires dkimpy + DNS.
    """

    if not dkim_sig:
        return "NONE", "No DKIM-Signature header present"

    required_tags = ["v=", "a=", "d=", "s=", "h=", "bh=", "b="]
    missing = [t for t in required_tags if t not in dkim_sig]
    if missing:
        return "FAIL", f"DKIM-Signature missing required tags: {', '.join(missing)}"

    # Check for obviously invalid/placeholder signatures
    b_match = re.search(r"\bb=([A-Za-z0-9+/=\s]+)", dkim_sig)
    if b_match:
        sig_val = b_match.group(1).replace(" ", "").replace("\t", "")
        if len(sig_val) < 20 or sig_val in ("invalid", "==", ""):
            return "FAIL", "DKIM-Signature body hash appears invalid or placeholder"

    return "PASS", "DKIM-Signature structure is well-formed (crypto not verified offline)"


def analyze_auth(parsed) -> AuthResult:

    """
    Run SPF / DKIM / DMARC alignment analysis on a ParsedEmail.
    """

    from_domain = extract_domain(parsed.from_address)
    envelope_from_domain = extract_domain(parsed.return_path)
    dkim_domain = extract_dkim_domain(parsed.dkim_signature)
    reply_to_domain = extract_domain(parsed.reply_to) if parsed.reply_to else ""

    sender_ip, sender_hostname = extract_sender_ip(parsed.received)

    # --- SPF (structural) ---
    if not envelope_from_domain:
        spf = "NONE"
        spf_detail = "No Return-Path / envelope-from found; SPF cannot be checked"
    elif envelope_from_domain == from_domain:
        spf = "PASS"
        spf_detail = f"Envelope-from domain '{envelope_from_domain}' matches From domain '{from_domain}'"
    else:
        # Check for common free bulk mailer domains 
        free_bulk = {"mailchimp.com", "sendgrid.net", "amazonses.com", "mailgun.org",
                     "mandrillapp.com", "postmarkapp.com"}
        if envelope_from_domain in free_bulk:
            spf = "SOFTFAIL"
            spf_detail = (f"Envelope-from uses bulk mailer '{envelope_from_domain}' "
                          f"— misaligned from header domain '{from_domain}' but common for ESPs")
        else:
            spf = "FAIL"
            spf_detail = (f"Envelope-from domain '{envelope_from_domain}' does NOT match "
                          f"From domain '{from_domain}' — strong phishing indicator")

    # --- DKIM ---
    dkim, dkim_detail = check_dkim_structure(parsed.dkim_signature)
    if dkim == "PASS" and dkim_domain and dkim_domain != from_domain:
        dkim = "FAIL"
        dkim_detail = (f"DKIM signing domain '{dkim_domain}' does not match "
                       f"From domain '{from_domain}' — misalignment")

    # --- DMARC (alignment) ---
    # DMARC passes if either SPF or DKIM aligns with the From domain
    spf_aligned = spf in ("PASS", "SOFTFAIL") and envelope_from_domain == from_domain
    dkim_aligned = dkim == "PASS" and dkim_domain == from_domain

    if spf_aligned or dkim_aligned:
        dmarc = "PASS"
        mechanism = "SPF" if spf_aligned else "DKIM"
        dmarc_detail = f"DMARC alignment PASS via {mechanism}"
    elif not from_domain:
        dmarc = "NONE"
        dmarc_detail = "Cannot evaluate DMARC without a parseable From domain"
    else:
        dmarc = "FAIL"
        dmarc_detail = (f"Neither SPF nor DKIM aligns with From domain '{from_domain}'. "
                        "Email would fail published DMARC policy.")

    return AuthResult(
        from_domain=from_domain,
        envelope_from_domain=envelope_from_domain,
        dkim_domain=dkim_domain,
        reply_to_domain=reply_to_domain,
        spf=spf,
        spf_detail=spf_detail,
        dkim=dkim,
        dkim_detail=dkim_detail,
        dmarc=dmarc,
        dmarc_detail=dmarc_detail,
        sender_ip=sender_ip,
        sender_hostname=sender_hostname,
    )
