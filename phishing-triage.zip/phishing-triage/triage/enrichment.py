"""  Kerkulah Collins 02/18/2025

 Threat intel enrichment using VirusTotal, URLhaus, AbuseIPDB, Shodan.

Set API keys in config.py or environment variables:
  VIRUSTOTAL
  ABUSEIPDB
  SHODAN
"""

import os
import base64
import time
import logging
import hashlib
from dataclasses import dataclass, field
from typing import Optional
import requests

logger = logging.getLogger(__name__)

TIMEOUT = 10  # seconds per request


@dataclass
class VTResult:
    url: str
    malicious: int = 0
    suspicious: int = 0
    harmless: int = 0
    undetected: int = 0
    total: int = 0
    permalink: str = ""
    error: Optional[str] = None


@dataclass
class URLhausResult:
    url: str
    status: str = "unknown"   # online / offline / unknown / listed
    threat: str = ""
    tags: list[str] = field(default_factory=list)
    error: Optional[str] = None


@dataclass
class AbuseIPDBResult:
    ip: str
    abuse_score: int = 0
    total_reports: int = 0
    country: str = ""
    isp: str = ""
    is_tor: bool = False
    error: Optional[str] = None


@dataclass
class ShodanResult:
    ip: str
    hostnames: list[str] = field(default_factory=list)
    org: str = ""
    country: str = ""
    open_ports: list[int] = field(default_factory=list)
    vulns: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    error: Optional[str] = None


@dataclass
class EnrichmentBundle:
    virustotal: list[VTResult] = field(default_factory=list)
    urlhaus: list[URLhausResult] = field(default_factory=list)
    abuseipdb: Optional[AbuseIPDBResult] = None
    shodan: Optional[ShodanResult] = None


def _vt_url_id(url: str) -> str:

    """VirusTotal URL ID is base64url of the URL (no padding)."""
    
    return base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")


def check_virustotal(url: str, api_key: str) -> VTResult:
    if not api_key:
        return VTResult(url=url, error="No VirusTotal API key configured")
    headers = {"x-apikey": api_key}
    url_id = _vt_url_id(url)
    try:
        r = requests.get(
            f"https://www.virustotal.com/api/v3/urls/{url_id}",
            headers=headers, timeout=TIMEOUT
        )
        if r.status_code == 404:
            # URL not seen before — submit it
            submit = requests.post(
                "https://www.virustotal.com/api/v3/urls",
                headers=headers,
                data={"url": url},
                timeout=TIMEOUT,
            )
            if submit.status_code not in (200, 202):
                return VTResult(url=url, error=f"VT submit failed: {submit.status_code}")
            time.sleep(3)
            r = requests.get(
                f"https://www.virustotal.com/api/v3/urls/{url_id}",
                headers=headers, timeout=TIMEOUT
            )
        if r.status_code != 200:
            return VTResult(url=url, error=f"VT API error: {r.status_code}")
        data = r.json()
        stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
        return VTResult(
            url=url,
            malicious=stats.get("malicious", 0),
            suspicious=stats.get("suspicious", 0),
            harmless=stats.get("harmless", 0),
            undetected=stats.get("undetected", 0),
            total=sum(stats.values()),
            permalink=f"https://www.virustotal.com/gui/url/{url_id}",
        )
    except requests.RequestException as e:
        return VTResult(url=url, error=str(e))


def check_urlhaus(url: str) -> URLhausResult:
    try:
        r = requests.post(
            "https://urlhaus-api.abuse.ch/v1/url/",
            data={"url": url},
            timeout=TIMEOUT,
        )
        if r.status_code != 200:
            return URLhausResult(url=url, error=f"URLhaus API error: {r.status_code}")
        data = r.json()
        if data.get("query_status") == "no_results":
            return URLhausResult(url=url, status="not_listed")
        tags = [t.get("tag", "") for t in data.get("tags", [])] if data.get("tags") else []
        return URLhausResult(
            url=url,
            status=data.get("url_status", "unknown"),
            threat=data.get("threat", ""),
            tags=tags,
        )
    except requests.RequestException as e:
        return URLhausResult(url=url, error=str(e))


def check_abuseipdb(ip: str, api_key: str) -> AbuseIPDBResult:
    if not api_key:
        return AbuseIPDBResult(ip=ip, error="No AbuseIPDB API key configured")
    if not ip:
        return AbuseIPDBResult(ip="", error="No IP provided")
    try:
        r = requests.get(
            "https://api.abuseipdb.com/api/v2/check",
            params={"ipAddress": ip, "maxAgeInDays": 90, "verbose": True},
            headers={"Key": api_key, "Accept": "application/json"},
            timeout=TIMEOUT,
        )
        if r.status_code != 200:
            return AbuseIPDBResult(ip=ip, error=f"AbuseIPDB API error: {r.status_code}")
        data = r.json().get("data", {})
        return AbuseIPDBResult(
            ip=ip,
            abuse_score=data.get("abuseConfidenceScore", 0),
            total_reports=data.get("totalReports", 0),
            country=data.get("countryCode", ""),
            isp=data.get("isp", ""),
            is_tor=data.get("isTor", False),
        )
    except requests.RequestException as e:
        return AbuseIPDBResult(ip=ip, error=str(e))


def check_shodan(ip: str, api_key: str) -> ShodanResult:
    if not api_key:
        return ShodanResult(ip=ip, error="No Shodan API key configured")
    if not ip:
        return ShodanResult(ip="", error="No IP provided")
    try:
        r = requests.get(
            f"https://api.shodan.io/shodan/host/{ip}",
            params={"key": api_key},
            timeout=TIMEOUT,
        )
        if r.status_code == 404:
            return ShodanResult(ip=ip, error="IP not found in Shodan")
        if r.status_code != 200:
            return ShodanResult(ip=ip, error=f"Shodan API error: {r.status_code}")
        data = r.json()
        ports = sorted(set(item.get("port", 0) for item in data.get("data", [])))
        vulns = list(data.get("vulns", {}).keys())
        return ShodanResult(
            ip=ip,
            hostnames=data.get("hostnames", []),
            org=data.get("org", ""),
            country=data.get("country_name", ""),
            open_ports=ports,
            vulns=vulns,
            tags=data.get("tags", []),
        )
    except requests.RequestException as e:
        return ShodanResult(ip=ip, error=str(e))


def enrich(
    urls: list[str],
    sender_ip: Optional[str],
    vt_key: str = "",
    abuseipdb_key: str = "",
    shodan_key: str = "",
    max_urls: int = 5,
) -> EnrichmentBundle:
    """
    Run all enrichment checks. Caps URL checks at max_urls to avoid rate limits.
    Pass api keys directly or they'll be read from env vars.
    """
    vt_key = vt_key or os.getenv("VIRUSTOTAL_API_KEY", "")
    abuseipdb_key = abuseipdb_key or os.getenv("ABUSEIPDB_API_KEY", "")
    shodan_key = shodan_key or os.getenv("SHODAN_API_KEY", "")

    vt_results = []
    urlhaus_results = []

    for url in urls[:max_urls]:
        logger.info(f"[VT] Checking {url}")
        vt_results.append(check_virustotal(url, vt_key))

        logger.info(f"[URLhaus] Checking {url}")
        urlhaus_results.append(check_urlhaus(url))

    abuseipdb_result = None
    shodan_result = None
    if sender_ip:
        logger.info(f"[AbuseIPDB] Checking {sender_ip}")
        abuseipdb_result = check_abuseipdb(sender_ip, abuseipdb_key)

        logger.info(f"[Shodan] Checking {sender_ip}")
        shodan_result = check_shodan(sender_ip, shodan_key)

    return EnrichmentBundle(
        virustotal=vt_results,
        urlhaus=urlhaus_results,
        abuseipdb=abuseipdb_result,
        shodan=shodan_result,
    )
