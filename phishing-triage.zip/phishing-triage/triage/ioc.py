"""  Kerkulah Collins 02/20/2025
URL defanging, hash extraction, and IOC normalization.
"""
import hashlib
import re
import ipaddress
from dataclasses import dataclass
from urllib.parse import urlparse
from typing import Optional


@dataclass
class UrlIOC:
    original: str
    defanged: str
    scheme: str
    domain: str
    path: str
    is_ip: bool
    is_http: bool           # True = unencrypted
    is_redirect: bool
    is_tracking_pixel: bool
    is_typosquat: bool
    typosquat_target: Optional[str]
    md5: str
    sha256: str


# Well known brands commonly targeted by typosquatters
BRAND_PATTERNS = {
    "paypal": r"paypa[l1i]|paypai|payp4l|p4ypal",
    "google": r"g[o0]{2}gle|go+gle|g00gle",
    "microsoft": r"micros[o0]ft|microsoFt|m1crosoft",
    "amazon": r"amaz[o0]n|4mazon|amazzon",
    "apple": r"app1e|appl3|4pple",
    "facebook": r"faceb[o0]{2}k|face-book|faceboook",
    "netflix": r"netfl1x|n3tflix|netfilx",
    "instagram": r"1nstagram|instagr4m",
    "dropbox": r"dr0pbox|dropb0x",
    "chase": r"cha5e|ch4se",
    "wellsfargo": r"we11sfargo|wellsfarg0",
    "bankofamerica": r"b4nkofamerica|bankofamerica-",
    "irs": r"irs-gov|irs\.com|iirs",
    "dhl": r"dh1\.com|dh[^.]+-express",
    "fedex": r"fedex-|fed-ex",
    "ups": r"ups-delivery|myups",
}

TRACKING_PATTERNS = re.compile(
    r"pixel|tracker|track\.|beacon|open\.php|gif\?|/t/|/track|"
    r"click\.|unsubscribe|mailchimp|campaign-archive",
    re.IGNORECASE
)

REDIRECT_PATTERNS = re.compile(
    r"redirect|redir|url=http|goto=http|link=http|out\.php|"
    r"click\.php|go\.php|r\.php",
    re.IGNORECASE
)


def defang(url: str) -> str:
    """Defang a URL so it cannot be accidentally clicked or auto-linked."""
    try:
        parsed = urlparse(url)
        # Bracket the scheme: https -> hxxps, then replace :// with [://]
        scheme = parsed.scheme.replace("tt", "xx")  # http->hxxp, https->hxxps
        netloc_defanged = parsed.netloc.replace(".", "[.]")
        rest = url[len(parsed.scheme) + len("://"):]  # everything after scheme://
        # Rebuild: hxxps[://]evil[.]com/path
        defanged = f"{scheme}[://]{netloc_defanged}{parsed.path}"
        if parsed.query:
            defanged += "?" + parsed.query
        if parsed.fragment:
            defanged += "#" + parsed.fragment
    except Exception:
        defanged = url.replace(".", "[.]").replace("://", "[://]")
    return defanged


def is_ip_host(host: str) -> bool:
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def detect_typosquat(domain: str) -> tuple[bool, Optional[str]]:
    clean = domain.lower().split(":")[0]  # strip port
    for brand, pattern in BRAND_PATTERNS.items():
        if re.search(pattern, clean, re.IGNORECASE):
            # Make sure it's not the actual brand domain
            actual = brand.replace("bankofamerica", "bankofamerica") + ".com"
            if clean not in (f"{brand}.com", f"www.{brand}.com"):
                return True, brand
    return False, None


def hash_string(s: str) -> tuple[str, str]:
    encoded = s.encode("utf-8")
    return (
        hashlib.md5(encoded).hexdigest(),
        hashlib.sha256(encoded).hexdigest(),
    )


def analyze_url(url: str) -> UrlIOC:
    try:
        parsed = urlparse(url)
        domain = parsed.netloc or ""
        path = parsed.path or ""
        scheme = parsed.scheme.lower()
    except Exception:
        domain, path, scheme = "", "", "http"

    is_ip = is_ip_host(domain.split(":")[0])
    is_http = scheme == "http"
    is_redirect = bool(REDIRECT_PATTERNS.search(url))
    is_tracking = bool(TRACKING_PATTERNS.search(url))
    is_typosquat, typosquat_target = detect_typosquat(domain)

    md5, sha256 = hash_string(url)

    return UrlIOC(
        original=url,
        defanged=defang(url),
        scheme=scheme,
        domain=domain,
        path=path,
        is_ip=is_ip,
        is_http=is_http,
        is_redirect=is_redirect,
        is_tracking_pixel=is_tracking,
        is_typosquat=is_typosquat,
        typosquat_target=typosquat_target,
        md5=md5,
        sha256=sha256,
    )


def analyze_urls(urls: list[str]) -> list[UrlIOC]:
    return [analyze_url(u) for u in urls]
