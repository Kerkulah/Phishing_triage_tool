""" Kerkulah Collins 02/25/2025
Explainable phishing risk scoring engine.

Each rule returns a ScoringSignal. The final score is capped at 100. Verdict thresholds:
  >= 70  → PHISHING
  >= 35  → SUSPICIOUS
  <  35  → CLEAN
"""
import re
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class ScoringSignal:
    rule_id: str
    category: str           # AUTH | URL | ATTACHMENT | HEADER | CONTENT | INTEL
    severity: str           # HIGH | MEDIUM | LOW | INFO
    weight: int
    title: str
    detail: str
    mitre_technique: Optional[str] = None   # e.g. T1566.001


@dataclass
class ScoringResult:
    score: int
    verdict: str            # PHISHING | SUSPICIOUS | CLEAN
    signals: list[ScoringSignal] = field(default_factory=list)
    triage_summary: str = ""


URGENCY_WORDS = re.compile(
    r"\b(urgent|immediate|immediately|verify|limited|suspended|"
    r"suspension|action required|confirm|account.*locked|"
    r"unusual.*activity|unauthorized|expire|expires|24.?hour|"
    r"click.*now|act.*now|must.*verify)\b",
    re.IGNORECASE
)

FREE_EMAIL_DOMAINS = {
    "gmail.com", "yahoo.com", "hotmail.com", "outlook.com",
    "aol.com", "mail.com", "protonmail.com", "icloud.com",
    "yandex.com", "gmx.com", "zoho.com",
}


def score_email(parsed, auth, url_iocs, enrichment=None) -> ScoringResult:
    signals: list[ScoringSignal] = []

    # ── AUTH SIGNALS ───────────────────────────────────────────────────────────

    if auth.spf == "FAIL":
        signals.append(ScoringSignal(
            rule_id="AUTH001", category="AUTH", severity="HIGH", weight=25,
            title="SPF FAIL",
            detail=(f"Envelope-from domain '{auth.envelope_from_domain}' does not match "
                    f"From domain '{auth.from_domain}'. Classic spoofing pattern."),
            mitre_technique="T1566.001",
        ))
    elif auth.spf == "SOFTFAIL":
        signals.append(ScoringSignal(
            rule_id="AUTH002", category="AUTH", severity="MEDIUM", weight=10,
            title="SPF SOFTFAIL",
            detail=f"SPF ~all policy: misalignment between envelope and header domains.",
        ))

    if auth.dkim == "FAIL":
        signals.append(ScoringSignal(
            rule_id="AUTH003", category="AUTH", severity="HIGH", weight=20,
            title="DKIM Invalid / Missing",
            detail=auth.dkim_detail,
            mitre_technique="T1566.001",
        ))

    if auth.dmarc == "FAIL":
        signals.append(ScoringSignal(
            rule_id="AUTH004", category="AUTH", severity="HIGH", weight=10,
            title="DMARC FAIL",
            detail=auth.dmarc_detail,
        ))

    if auth.reply_to_domain and auth.reply_to_domain != auth.from_domain:
        signals.append(ScoringSignal(
            rule_id="AUTH005", category="AUTH", severity="MEDIUM", weight=10,
            title="Reply-To Domain Mismatch",
            detail=(f"Reply-To domain '{auth.reply_to_domain}' differs from "
                    f"From domain '{auth.from_domain}' — replies go to a different actor."),
            mitre_technique="T1566.001",
        ))

    if auth.envelope_from_domain and auth.from_domain:
        if auth.envelope_from_domain != auth.from_domain:
            rp_parts = auth.envelope_from_domain.split(".")
            from_parts = auth.from_domain.split(".")
            if rp_parts[-2:] != from_parts[-2:]:   # different registrable domain
                signals.append(ScoringSignal(
                    rule_id="AUTH006", category="AUTH", severity="MEDIUM", weight=8,
                    title="Return-Path Domain Mismatch",
                    detail=(f"Return-Path uses '{auth.envelope_from_domain}', "
                            f"From header shows '{auth.from_domain}'."),
                ))

    # ── URL SIGNALS ────────────────────────────────────────────────────────────

    typosquat_urls = [u for u in url_iocs if u.is_typosquat]
    if typosquat_urls:
        targets = list({u.typosquat_target for u in typosquat_urls})
        signals.append(ScoringSignal(
            rule_id="URL001", category="URL", severity="HIGH", weight=25,
            title=f"Typosquatted Domain(s) Detected",
            detail=(f"{len(typosquat_urls)} URL(s) impersonate: {', '.join(targets)}. "
                    f"Example: {typosquat_urls[0].defanged}"),
            mitre_technique="T1566.001",
        ))

    tracking_urls = [u for u in url_iocs if u.is_tracking_pixel]
    if tracking_urls:
        signals.append(ScoringSignal(
            rule_id="URL002", category="URL", severity="MEDIUM", weight=10,
            title="Tracking Pixel / Beacon Detected",
            detail=(f"Found {len(tracking_urls)} tracking element(s). "
                    "These confirm email open and harvest recipient data."),
            mitre_technique="T1598",
        ))

    ip_urls = [u for u in url_iocs if u.is_ip]
    if ip_urls:
        signals.append(ScoringSignal(
            rule_id="URL003", category="URL", severity="HIGH", weight=20,
            title="IP Address Used in URL",
            detail=(f"{len(ip_urls)} link(s) use raw IP addresses instead of domains. "
                    f"Example: {ip_urls[0].defanged}"),
            mitre_technique="T1566.001",
        ))

    http_urls = [u for u in url_iocs if u.is_http]
    if http_urls:
        signals.append(ScoringSignal(
            rule_id="URL004", category="URL", severity="LOW", weight=5,
            title="Unencrypted HTTP Links",
            detail=f"{len(http_urls)} link(s) use HTTP (not HTTPS) — data transmitted in cleartext.",
        ))

    redirect_urls = [u for u in url_iocs if u.is_redirect]
    if redirect_urls:
        signals.append(ScoringSignal(
            rule_id="URL005", category="URL", severity="MEDIUM", weight=8,
            title="Open Redirect Pattern",
            detail=(f"{len(redirect_urls)} URL(s) appear to use open redirect patterns "
                    "to obscure the final destination."),
        ))

    # ── ATTACHMENT SIGNALS ─────────────────────────────────────────────────────

    bad_atts = [a for a in parsed.attachments if a.is_suspicious]
    if bad_atts:
        names = ", ".join(a.filename for a in bad_atts)
        signals.append(ScoringSignal(
            rule_id="ATT001", category="ATTACHMENT", severity="HIGH", weight=30,
            title="Suspicious Attachment(s)",
            detail=f"Potentially malicious file type(s) attached: {names}",
            mitre_technique="T1566.001",
        ))

    # ── HEADER / CONTENT SIGNALS ───────────────────────────────────────────────

    subject = parsed.subject or ""
    if URGENCY_WORDS.search(subject):
        signals.append(ScoringSignal(
            rule_id="HDR001", category="HEADER", severity="MEDIUM", weight=15,
            title="Urgency Language in Subject",
            detail=f'Subject uses social-engineering urgency: "{subject}"',
            mitre_technique="T1566",
        ))

    if auth.from_domain in FREE_EMAIL_DOMAINS:
        signals.append(ScoringSignal(
            rule_id="HDR002", category="HEADER", severity="LOW", weight=5,
            title="Free Email Provider as From Domain",
            detail=(f"Sender uses a free email domain '{auth.from_domain}'. "
                    "Legitimate business/service emails use custom domains."),
        ))

    body = (parsed.body_text + parsed.body_html).lower()
    if URGENCY_WORDS.search(body):
        signals.append(ScoringSignal(
            rule_id="CNT001", category="CONTENT", severity="LOW", weight=5,
            title="Urgency Language in Body",
            detail="Email body contains social-engineering urgency language.",
        ))

    # Multiple different link domains is suspicious
    link_domains = set()
    for u in url_iocs:
        parts = u.domain.split(".")
        if len(parts) >= 2:
            link_domains.add(".".join(parts[-2:]))
    if len(link_domains) > 3:
        signals.append(ScoringSignal(
            rule_id="URL006", category="URL", severity="LOW", weight=5,
            title="High URL Domain Diversity",
            detail=(f"Email links span {len(link_domains)} different domains — "
                    "unusual for legitimate transactional mail."),
        ))

    # ── THREAT INTEL SIGNALS ───────────────────────────────────────────────────

    if enrichment:
        for vt in enrichment.virustotal:
            if not vt.error and vt.malicious > 0:
                signals.append(ScoringSignal(
                    rule_id="INTEL001", category="INTEL", severity="HIGH", weight=30,
                    title="VirusTotal Detections",
                    detail=(f"URL flagged malicious by {vt.malicious}/{vt.total} VT engines: "
                            f"{vt.url[:80]}"),
                    mitre_technique="T1566.001",
                ))

        for uh in enrichment.urlhaus:
            if not uh.error and uh.status in ("online", "listed"):
                signals.append(ScoringSignal(
                    rule_id="INTEL002", category="INTEL", severity="HIGH", weight=25,
                    title="URLhaus Blacklist Hit",
                    detail=f"URL listed in URLhaus malware feed. Threat: {uh.threat or 'phishing/malware'}",
                    mitre_technique="T1566.001",
                ))

        if enrichment.abuseipdb and not enrichment.abuseipdb.error:
            score = enrichment.abuseipdb.abuse_score
            if score >= 75:
                signals.append(ScoringSignal(
                    rule_id="INTEL003", category="INTEL", severity="HIGH", weight=20,
                    title=f"High AbuseIPDB Score: {score}/100",
                    detail=(f"Sender IP {enrichment.abuseipdb.ip} has {score}% abuse confidence "
                            f"across {enrichment.abuseipdb.total_reports} reports. "
                            f"ISP: {enrichment.abuseipdb.isp}"),
                ))
            elif score >= 25:
                signals.append(ScoringSignal(
                    rule_id="INTEL004", category="INTEL", severity="MEDIUM", weight=10,
                    title=f"Moderate AbuseIPDB Score: {score}/100",
                    detail=f"Sender IP {enrichment.abuseipdb.ip} has moderate abuse history.",
                ))

            if enrichment.abuseipdb.is_tor:
                signals.append(ScoringSignal(
                    rule_id="INTEL005", category="INTEL", severity="HIGH", weight=15,
                    title="Sender IP is a Tor Exit Node",
                    detail=f"IP {enrichment.abuseipdb.ip} is a known Tor exit node — anonymizing sender.",
                    mitre_technique="T1090",
                ))

        if enrichment.shodan and not enrichment.shodan.error:
            if enrichment.shodan.vulns:
                signals.append(ScoringSignal(
                    rule_id="INTEL006", category="INTEL", severity="MEDIUM", weight=5,
                    title=f"Vulnerable Host: {len(enrichment.shodan.vulns)} CVE(s)",
                    detail=(f"Sender IP has known vulnerabilities per Shodan: "
                            f"{', '.join(enrichment.shodan.vulns[:5])}"),
                ))

    # ── COMPUTE FINAL SCORE ────────────────────────────────────────────────────

    raw_score = sum(s.weight for s in signals)
    final_score = min(raw_score, 100)

    if final_score >= 70:
        verdict = "PHISHING"
    elif final_score >= 35:
        verdict = "SUSPICIOUS"
    else:
        verdict = "CLEAN"

    # Build triage summary
    high_signals = [s for s in signals if s.severity == "HIGH"]
    summary_parts = []
    if high_signals:
        summary_parts.append(f"{len(high_signals)} high-severity indicator(s): " +
                              "; ".join(s.title for s in high_signals[:3]))
    if not summary_parts:
        summary_parts.append("No high-severity indicators found")

    triage_summary = f"[{verdict}] Score {final_score}/100. " + ". ".join(summary_parts) + "."

    return ScoringResult(
        score=final_score,
        verdict=verdict,
        signals=signals,
        triage_summary=triage_summary,
    )
