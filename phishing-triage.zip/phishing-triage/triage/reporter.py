""" Kerkulah Collins 02/23/2025
Generate JSON case files and Markdown incident tickets.
"""
import json
import uuid
from datetime import datetime, timezone
from dataclasses import asdict
from typing import Optional


def _safe_asdict(obj):

    """Convert dataclass to dict, handling nested dataclasses."""
    
    try:
        return asdict(obj)
    except TypeError:
        return str(obj)


def build_case_id() -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%d")
    short = str(uuid.uuid4())[:8].upper()
    return f"PHISH-{ts}-{short}"


def generate_json_report(
    case_id: str,
    filename: str,
    parsed,
    auth,
    url_iocs,
    scoring,
    enrichment=None,
) -> dict:
    """Build a structured JSON case file."""

    def url_ioc_dict(u):
        return {
            "original": u.original,
            "defanged": u.defanged,
            "domain": u.domain,
            "md5": u.md5,
            "sha256": u.sha256,
            "flags": {
                "is_typosquat": u.is_typosquat,
                "typosquat_target": u.typosquat_target,
                "is_tracking_pixel": u.is_tracking_pixel,
                "is_redirect": u.is_redirect,
                "is_ip_host": u.is_ip,
                "is_http": u.is_http,
            },
        }

    def att_dict(a):
        return {
            "filename": a.filename,
            "content_type": a.content_type,
            "size_bytes": a.size,
            "md5": a.md5,
            "sha256": a.sha256,
            "is_suspicious": a.is_suspicious,
        }

    def signal_dict(s):
        d = {
            "rule_id": s.rule_id,
            "category": s.category,
            "severity": s.severity,
            "weight": s.weight,
            "title": s.title,
            "detail": s.detail,
        }
        if s.mitre_technique:
            d["mitre_technique"] = s.mitre_technique
        return d

    report = {
        "case_id": case_id,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "filename": filename,
        "verdict": scoring.verdict,
        "risk_score": scoring.score,
        "triage_summary": scoring.triage_summary,
        "email": {
            "from": parsed.from_header,
            "from_address": parsed.from_address,
            "to": parsed.to,
            "subject": parsed.subject,
            "date": parsed.date,
            "message_id": parsed.message_id,
            "return_path": parsed.return_path,
            "reply_to": parsed.reply_to,
            "x_mailer": parsed.x_mailer,
        },
        "authentication": {
            "spf": {
                "result": auth.spf,
                "detail": auth.spf_detail,
                "from_domain": auth.from_domain,
                "envelope_domain": auth.envelope_from_domain,
            },
            "dkim": {
                "result": auth.dkim,
                "detail": auth.dkim_detail,
                "signing_domain": auth.dkim_domain,
            },
            "dmarc": {
                "result": auth.dmarc,
                "detail": auth.dmarc_detail,
            },
            "sender_ip": auth.sender_ip,
            "sender_hostname": auth.sender_hostname,
        },
        "urls": [url_ioc_dict(u) for u in url_iocs],
        "attachments": [att_dict(a) for a in parsed.attachments],
        "scoring": {
            "signals": [signal_dict(s) for s in scoring.signals],
            "total_weight": sum(s.weight for s in scoring.signals),
            "capped_score": scoring.score,
        },
    }

    if enrichment:
        enrich_data: dict = {"virustotal": [], "urlhaus": [], "abuseipdb": None, "shodan": None}

        for vt in enrichment.virustotal:
            enrich_data["virustotal"].append({
                "url": vt.url,
                "malicious": vt.malicious,
                "suspicious": vt.suspicious,
                "total": vt.total,
                "permalink": vt.permalink,
                "error": vt.error,
            })

        for uh in enrichment.urlhaus:
            enrich_data["urlhaus"].append({
                "url": uh.url,
                "status": uh.status,
                "threat": uh.threat,
                "tags": uh.tags,
                "error": uh.error,
            })

        if enrichment.abuseipdb:
            a = enrichment.abuseipdb
            enrich_data["abuseipdb"] = {
                "ip": a.ip, "abuse_score": a.abuse_score,
                "total_reports": a.total_reports, "country": a.country,
                "isp": a.isp, "is_tor": a.is_tor, "error": a.error,
            }

        if enrichment.shodan:
            s = enrichment.shodan
            enrich_data["shodan"] = {
                "ip": s.ip, "org": s.org, "country": s.country,
                "hostnames": s.hostnames, "open_ports": s.open_ports,
                "vulns": s.vulns, "tags": s.tags, "error": s.error,
            }

        report["enrichment"] = enrich_data

    return report


SEVERITY_EMOJI = {"HIGH": "", "MEDIUM": "", "LOW": "", "INFO": ""}
VERDICT_EMOJI = {"PHISHING": "", "SUSPICIOUS": "", "CLEAN": ""}


def generate_markdown_ticket(report: dict) -> str:

    """Render a Markdown incident ticket from a JSON case report."""

    v = report["verdict"]
    score = report["risk_score"]
    email = report["email"]
    auth = report["authentication"]
    signals = report["scoring"]["signals"]
    urls = report["urls"]
    attachments = report["attachments"]

    verdict_line = f"{VERDICT_EMOJI.get(v,'?')} **{v}** — Risk Score: **{score}/100**"

    auth_table = (
        "| Check | Result | Detail |\n"
        "|-------|--------|--------|\n"
        f"| SPF | `{auth['spf']['result']}` | {auth['spf']['detail']} |\n"
        f"| DKIM | `{auth['dkim']['result']}` | {auth['dkim']['detail']} |\n"
        f"| DMARC | `{auth['dmarc']['result']}` | {auth['dmarc']['detail']} |\n"
    )

    signal_lines = "\n".join(
        f"- {SEVERITY_EMOJI.get(s['severity'],'?')} **[{s['rule_id']}] {s['title']}** (+{s['weight']})  \n"
        f"  {s['detail']}" +
        (f"  \n  MITRE: [{s['mitre_technique']}](https://attack.mitre.org/techniques/{s['mitre_technique'].replace('.','/')})"
         if s.get('mitre_technique') else "")
        for s in signals
    ) or "_No signals triggered._"

    url_lines = "\n".join(
        f"- `{u['defanged']}`  \n"
        f"  MD5: `{u['md5']}` | SHA256: `{u['sha256'][:32]}...`  \n"
        f"  Flags: {', '.join(k for k,val in u['flags'].items() if val)}"
        for u in urls
    ) or "_No URLs found._"

    att_lines = "\n".join(
        f"- {'⚠️' if a['is_suspicious'] else '📎'} `{a['filename']}` "
        f"({a['content_type']}, {a['size_bytes']} bytes)  \n"
        f"  MD5: `{a['md5']}` | SHA256: `{a['sha256'][:32]}...`"
        for a in attachments
    ) or "_No attachments._"

    sender_ip = auth.get('sender_ip') or 'N/A'
    sender_host = auth.get('sender_hostname') or 'N/A'

    enrich_section = ""
    if "enrichment" in report:
        enrich = report["enrichment"]
        vt_lines = "\n".join(
            f"- `{e['url'][:80]}` → **{e['malicious']}/{e['total']}** detections"
            + (f" — [VT Report]({e['permalink']})" if e.get('permalink') else "")
            + (f" ⚠️ Error: {e['error']}" if e.get('error') else "")
            for e in enrich.get("virustotal", [])
        ) or "_Not checked._"

        uh_lines = "\n".join(
            f"- `{e['url'][:80]}` → status: **{e['status']}** threat: {e.get('threat') or 'N/A'}"
            for e in enrich.get("urlhaus", [])
        ) or "_Not checked._"

        ab = enrich.get("abuseipdb")
        ab_section = ""
        if ab and not ab.get("error"):
            ab_section = (
                f"\n### AbuseIPDB\n"
                f"- IP: `{ab['ip']}` | Score: **{ab['abuse_score']}/100** | "
                f"Reports: {ab['total_reports']} | Country: {ab['country']} | ISP: {ab['isp']}"
                + (" | **TOR EXIT NODE**" if ab.get('is_tor') else "")
            )

        sh = enrich.get("shodan")
        sh_section = ""
        if sh and not sh.get("error"):
            ports_str = ", ".join(str(p) for p in sh.get("open_ports", [])[:10])
            vulns_str = ", ".join(sh.get("vulns", [])[:5]) or "None"
            sh_section = (
                f"\n### Shodan\n"
                f"- IP: `{sh['ip']}` | Org: {sh['org']} | Country: {sh['country']}  \n"
                f"- Open ports: {ports_str or 'N/A'}  \n"
                f"- CVEs: {vulns_str}"
            )

        enrich_section = (
            f"\n## Threat Intel Enrichment\n\n"
            f"### VirusTotal\n{vt_lines}\n\n"
            f"### URLhaus\n{uh_lines}"
            f"{ab_section}"
            f"{sh_section}\n"
        )

    return f"""# Phishing Triage Report

**Case ID:** `{report['case_id']}`  
**Generated:** {report['generated_at']}  
**File:** `{report['filename']}`

---

## Verdict

{verdict_line}

> {report['triage_summary']}

---

## Email Metadata

| Field | Value |
|-------|-------|
| From | `{email['from']}` |
| From Address | `{email['from_address']}` |
| To | `{email['to']}` |
| Subject | {email['subject']} |
| Date | {email['date']} |
| Message-ID | `{email['message_id']}` |
| Return-Path | `{email['return_path']}` |
| Reply-To | `{email['reply_to'] or 'N/A'}` |
| Sender IP | `{sender_ip}` |
| Sender Hostname | `{sender_host}` |

---

## Authentication

{auth_table}

---

## Scoring Signals

{signal_lines}

---

## URLs / IOCs

{url_lines}

---

## Attachments

{att_lines}
{enrich_section}
---


"""
