# Phishing Triage Tool

Drop in a `.eml` — get an analyst ready verdict in under a second.

A fast, open source phishing triage tool for SOC analysts. Parses `.eml` files and produces explainable risk scores, defanged IOCs, and structured case files  no cloud dependency required.

---

## Features

- SPF / DKIM / DMARC** alignment analysis from email headers
- URL defanging + hash extraction (MD5 + SHA256) for safe IOC sharing
- Typosquat detection for 15+ major brands (PayPal, Google, Microsoft, Amazon...)
- Attachment analysis — flags 20+ malicious file types
- Explainable scoring — every point explained with rule ID + MITRE ATT&CK ref
- Threat intel enrichment — VirusTotal, URLhaus (free), AbuseIPDB, Shodan
- Output formats — JSON case file + Markdown incident ticket
- interfaces — REST API (Flask) 

---

## Quick Start

```bash

# 1. Start the web API
python app.py
# → http://localhost:8080
```

# 2. Clone and install
git clone https://github.com/yourname/phishing-triage
cd phishing-triage
pip install -r requirements.txt



## CLI Usage

```bash
# Single file
python triage_cli.py suspicious.eml

# With threat intel enrichment (requires API keys)
python triage_cli.py suspicious.eml --enrich

# Batch mode — analyze a whole folder
python triage_cli.py inbox/*.eml --batch --output-dir ./cases

# JSON output (for piping/SOAR integration)
python triage_cli.py suspicious.eml --json | jq .verdict

# Quiet mode — verdict only, good for scripting
python triage_cli.py suspicious.eml --quiet
echo "Exit code: $?"   # 0=clean, 1=phishing, 2=error
```


---

## REST API

### Start the server

```bash
python app.py
# or
gunicorn app:app -b 0.0.0.0:8080 --workers 2
```

### Endpoints

#### `POST /api/triage`

Analyze an `.eml` file. Returns a JSON case report.

```bash
curl -X POST http://localhost:8080/api/triage \
  -F "file=@suspicious.eml" \
  -F "enrich=1"
```

**Response:**
```json
{
  "case_id": "PHISH-20260513-A3F9B2C1",
  "verdict": "PHISHING",
  "risk_score": 82,
  "triage_summary": "[PHISHING] Score 82/100. 4 high-severity indicators...",
  "email": { "from": "...", "subject": "...", "date": "..." },
  "authentication": {
    "spf": { "result": "FAIL", "detail": "..." },
    "dkim": { "result": "FAIL", "detail": "..." },
    "dmarc": { "result": "FAIL", "detail": "..." }
  },
  "urls": [
    {
      "original": "http://paypa1-verify.com/...",
      "defanged": "hxxp[://]paypa1-verify[.]com/...",
      "md5": "abc123...",
      "sha256": "def456...",
      "flags": { "is_typosquat": true, "typosquat_target": "paypal" }
    }
  ],
  "attachments": [...],
  "scoring": { "signals": [...] }
}
```

#### `POST /api/triage/markdown`

Same as above, returns a `.md` incident ticket download.

```bash
curl -X POST http://localhost:5000/api/triage/markdown \
  -F "file=@suspicious.eml" \
  -o PHISH-20260513-A3F9B2C1.md
```

#### `GET /api/health`

```bash
curl http://localhost:5000/api/health
# {"status": "ok", "service": "phishing-triage"}
```

---

## Adding API Keys (Threat Intel Enrichment)

```bash
# Copy the example env file
cp .env.example .env

# Edit .env and add your keys:
VIRUSTOTAL_API_KEY=your_vt_key_here    # free at virustotal.com
ABUSEIPDB_API_KEY=your_abipdb_key     # free at abuseipdb.com
SHODAN_API_KEY=your_shodan_key        # free at shodan.io
# URLhaus requires no key
```

Then source it before running:
```bash
source .env && python app.py
# or
source .env && python triage_cli.py suspicious.eml --enrich
```
